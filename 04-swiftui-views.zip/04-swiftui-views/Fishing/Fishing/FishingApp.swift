//
//  FishingApp.swift
//  Fishing
//
//  Created by 赵子然 on 2021/7/3.
//

import SwiftUI

@main
struct FishingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
